window._config = {
    cognito: {
        userPoolId: 'us-east-1_xhkKQnUJH', 
        userPoolClientId: '7cjqnf6aea6ah0mcgg4preb3mb', 
        region: 'us-east-1' 
    },
    api: {
        invokeUrl: 'https://resje7xbqb.execute-api.us-east-1.amazonaws.com/dev' 
    }
};
