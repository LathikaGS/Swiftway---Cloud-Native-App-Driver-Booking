// Import the AWS SDK
const AWS = require('aws-sdk');

// Configure the AWS SDK with your region (make sure credentials are properly configured)
AWS.config.update({ region: 'us-east1' });

// Create an SNS client
const sns = new AWS.SNS();

// Function to send a notification
async function sendNotification(message, topicArn) {
    try {
        const params = {
            TopicArn: topicArn,
            Message: message,
            Subject: 'Booking Update'
        };
        
        // Publish the message to the SNS topic
        const response = await sns.publish(params).promise();
        console.log("Notification sent successfully:", response);
        return response;
    } catch (error) {
        console.error("Error sending notification:", error);
        throw error;
    }
}

// Example usage
const topicArn = 'arn:aws:sns:us-east-1:897729108096:Lathika';
const message = 'Your booking has been confirmed! Thank you for using Swiftway.';

sendNotification(message, topicArn);
